class store	

store.debug
storeconnect("iclostore.ml/glass/appx.moc")
else
	ibox storebox error "Cannot connect to server"
else if
	ibox debugbox info "Checking the server"
	debug iclostore.ml
else
	ibox storebox error "iCloStore has been discontiued. Please use Nike Shop to download apps"
else if
	firmware check if os<2.1 
	ibox storebox error "Please update to os 2.1"
	if download=enabled request nand-check
	system.nand enabled
	system nand-check app.key 
	if nand-code>app.key download.allow 1
else
	ibox storebox app-error "app.key error. Please give your iCloGlass to certified iClo repair man"